package com.real.athletic.index.users.service;

import com.real.athletic.index.users.dto.UserInterestsDTO;

public interface UserRegistrationService {

	UserInterestsDTO saveUserInterest(UserInterestsDTO userInterestsDTO);
}
