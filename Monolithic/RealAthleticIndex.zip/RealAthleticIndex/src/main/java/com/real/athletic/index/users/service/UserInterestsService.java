package com.real.athletic.index.users.service;

import com.real.athletic.index.users.model.UserInterests;

public interface UserInterestsService {

	UserInterests saveUserInterest(UserInterests userInterests);

}
