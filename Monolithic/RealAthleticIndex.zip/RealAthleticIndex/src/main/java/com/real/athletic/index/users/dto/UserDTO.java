package com.real.athletic.index.users.dto;

public class UserDTO {
}
